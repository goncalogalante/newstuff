import json
import datetime as datetime
import pytz

def retrieve_time(zone, country):
    zone = zone.capitalize()
    country = country.capitalize()

    #tz = pytz.timezone('Europe/Lisbon')
    #tz = pytz.timezone(zone + '/' +country)
    #current_time = datetime.datetime.now(tz).strftime("%H:%M")
    current_time = 10

    return current_time

def lambda_handler(event, context):

    agent = event['agent']
    actionGroup = event['actionGroup']
    function = event['function']
    parameters = event.get('parameters', [])

    country = parameters[0]['value']
    zone = parameters[1]['value']

    current_time = retrieve_time(zone, country)

    # Execute your business logic here. For more information, refer to: https://docs.aws.amazon.com/bedrock/latest/userguide/agents-lambda.html
    responseBody =  {
        "TEXT": {
            #"body": "The function {} was called successfully! The current time is {} and the chosen zone is {}".format(function, current_time)
            "body": "The function {} was called successfully! zone is {}. current time is {}".format(function, zone, current_time)
        }
    }

    action_response = {
        'actionGroup': actionGroup,
        'function': function,
        'functionResponse': {
            'responseBody': responseBody
        }

    }

    dummy_function_response = {'response': action_response, 'messageVersion': event['messageVersion']}
    print("Response: {}".format(dummy_function_response))

    return dummy_function_response